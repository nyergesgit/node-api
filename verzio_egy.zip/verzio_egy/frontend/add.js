
function sendPost(){
    const data = document.getElementById("keresztnev").value+";"+document.getElementById("vezeteknev").value+";"+document.getElementById("lakcim").value+";"+document.getElementById("Osztaly").value+";"+document.getElementById("Igazolvanyszam").value;
    console.log(data);
      navigator.sendBeacon('http:localhost:3000/savedetails/'+ data);
      console.log(data);
    }

const sqlite3 = require("sqlite3").verbose();
const fs = require('fs');

fs.open('tanulok.db', 'w', function (err, file) {
  if (err) throw err;
  console.log('Mentve!');
});

const db = new sqlite3.Database("./tanulok.db", sqlite3.OPEN_READWRITE, (err) => {
    if (err) return console.error(err.message);
  
    console.log("kapcsolat létrejött");
  });
  
db.run('CREATE TABLE tanulok(id INTEGER PRIMARY KEY AUTOINCREMENT, keresztnev TEXT NOT NULL, vezeteknev TEXT NOT NULL, lakcim TEXT NOT NULL, Osztaly TEXT NOT NULL, Igazolvanyszam TEXT NOT NULL)');

/*
const sql ='INSERT INTO employees(name, email, address) VALUES(?,?,?)';
db.run(sql, ["mike","asd@gmail.com", "aaaaaa aaaa"], (err)=>{
    if(err) return console.error(err.message);

    console.log("A new row added!");
});
*/
